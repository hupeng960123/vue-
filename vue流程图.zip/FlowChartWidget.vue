<template>
  <div class="flowBox" ref="flowBox" :name="name" :style="{'height':height||'600px','width':width||'1600px'}">
    <div class="left_Box" ref="left_Box" :style="{'height':height||'600px'}">
      <div ref="iconBtn" class="iconBtn" v-for="(item,index) in getIconList" :key="index"
           @mousedown="chooseIcon(item,1)"></div>
    </div>
    <div class="center_box" ref="center_box" :style="{'height':height||'600px'}">
      <div class="backgroundImg">
        <div class="drawContent"
             style="position: absolute; transform-origin: 0% 0% 0px; background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2UwZTBlMCIgb3BhY2l0eT0iMC4yIiBzdHJva2Utd2lkdGg9IjEiLz48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZTBlMGUwIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=); width: 4800px; height: 6000px; left: 0px; top: 0px;"></div>
      </div>
      <canvas width="960" height="1200" id="myCanvas" ref="myCanvas" style="display: none"></canvas>
      <div v-for="(item,index) in shapeArray" :key="item.id" :id="item.id" class="shape_box" ref="shape_box"
           @mousedown.stop="chooseIcon(item,2,$event)" @dblclick="shapeEdit(item)"
           :style="{width:item.width+20+'px',height:item.height+20+'px',left:item.x+'px',top:item.y+'px','z-index':item.z}">
        <canvas :width="item.width+20" :height="item.height+20" :class="['shape_canvas_'+index]"></canvas>
      </div>
      <div class="link_point_canvas" v-show="link_point_canvas.show"
           :style="{
             position:'absolute',
             'z-index':link_point_canvas.z+2,
             left:link_point_canvas.x+'px',
             top:link_point_canvas.y+'px',
             width:link_point_canvas.width+'px',
             height:link_point_canvas.height+'px'
      }"></div>
      <div v-for="item in lineArray" :key="item.id" class="lineBox" :id="item.id"
           :style="{width:item.width+20+'px',height:item.height+20+'px',left:item.x-10+'px',top:item.y-10+'px'}">
        <canvas :width="item.width+20" :height="item.height+20"></canvas>
      </div>
      <div v-if="shapeContour" class="shape_contour"
           :style="{left:shapeContour.left+'px',top:shapeContour.top+'px','z-index':shapeContour.z+1}">
        <div class="ponit_item" v-for="(item,index) in shapeContour.point" :key="index"
             :style="{left:item.x-5+'px',top:item.y-5+'px'}"
             @mousedown.stop="creatLine(item,$event,index,shapeContour.id)"></div>
      </div>
      <div v-show="showCheck" class="shape_controls"
           :style="{left:isCheck.x+9+'px',top:isCheck.y+9+'px',width:isCheck.width+'px',height:isCheck.height+'px'}">
        <div class="shape_controller nw" :style="{left:'-4px',top:'-4px','z-index':isCheck.z+2}"
             @mousedown.stop="zoomClick(1,$event)"></div>
        <div class="shape_controller ne" :style="{left:isCheck.width-4+'px',top:'-4px','z-index':isCheck.z+2}"
             @mousedown.stop="zoomClick(2,$event)"></div>
        <div class="shape_controller se"
             :style="{left:isCheck.width-4+'px',top:isCheck.height-4+'px','z-index':isCheck.z+2}"
             @mousedown.stop="zoomClick(3,$event)"></div>
        <div class="shape_controller sw" :style="{left:'-4px',top:isCheck.height-4+'px','z-index':isCheck.z+2}"
             @mousedown.stop="zoomClick(4,$event)"></div>
      </div>
      <div class="editText" v-show="isEdit" :style="editPlace">
        <textarea v-if="editPlace" class="input_text" v-model="textValue" @blur="editChange" ref="editText"
                  :style="{height:editPlace.height}"></textarea>
      </div>
    </div>
    <div v-show="showRightValue" class="right_box" ref="right_box"
         :style="{'height':height||'600px',width:rightWidth+'px'}">
      <div class="left_move" @mousedown="widthMoveStar"></div>
      <div ref="insertDom" v-for="(item,index) in widget" :key="index" style="vertical-align: top;"
           v-show="item.type==rightVNode_now"></div>
    </div>
  </div>
</template>

<script>
  import MixinsWidget from "./MixinsWidget";
  import common from "../utils/common"
  import component from "../utils/component";

  export default {
    name: "flowChartWidget",
    mixins: [MixinsWidget],
    props: {
      widget: {
        type: Array,
      }
    },
    computed: {
      getIconList() {
        if (Object.prototype.toString.call(this.widget) === '[object Array]') {
          return this.widget
        }
        return []
      }
    },
    data() {
      return {
        allWidth: 0,
        widthMove: false,
        widthMovePlace: null,
        rightWidth: '300',
        editPlace: null,
        editItem: null,
        textValue: '',
        isEdit: false,
        showRightValue: false,
        rightVNode: [],
        rightVNode_now: null,
        isChoose: false,
        beginPlace: null,
        showCheck: false,
        defaultRound: {
          x: -100,
          y: -100,
          radius: 40,
          width: 80,
          height: 80,
          value: null,
          type: 'round'
        },
        defaultRect: {
          x: -100,
          y: -100,
          width: 80,
          height: 80,
          value: null,
          type: 'rectangle'
        },
        shapeArray: [],
        lineArray: [],
        moveLine: null,
        shapeContour: null,
        isCheck: {},
        chooseLine: false,
        nowLine: null,
        timer: [],
        link_point_canvas: {
          x: 0,
          y: 0,
          width: 24,
          height: 24,
          z: 0,
          show: false
        },
        beginMovePlace: null
      }
    },

    mounted() {
      this.$nextTick(() => {
        this.setCenterWidth(300)

        this.$refs.flowBox.oncontextmenu = (e) => {
          return false;
        }
        let nowId = ''
        if (this.value) {
          let initData = JSON.parse(this.value)
          if (initData.length > 0) {
            // console.log(initData)
            initData.forEach((item, index) => {
              if (item.type == 'connect_line') {
                let obj_line = {
                  id: 'line' + common.allocateId(6, true),
                  type: 'connect_line',
                  x: item.pos[item.pos.length - 2][0],
                  y: item.pos[item.pos.length - 2][1],
                  origin_x: JSON.parse(JSON.stringify(item.pos[item.pos.length - 1][0])),
                  origin_y: JSON.parse(JSON.stringify(item.pos[item.pos.length - 1][1])),
                  e_id: item.next,
                  s_id: item.prev,
                  width: 0,
                  height: 0
                }
                obj_line.pos = [
                  item.pos[0],
                  item.pos[1]
                ]
                this.lineArray.push(obj_line)

              } else {
                if (item.select) {
                  nowId = item.id
                }
                let obj = {
                  type: item.type,
                  id: item.id,
                  x: item.x,
                  y: item.y,
                  label: item.label,
                  value: item.value,
                  data: item.data,
                  width: item.width,
                  height: item.height,
                  z: index + 1
                }
                if (item.type == 'round') {
                  obj.width = item.radius * 2
                  obj.height = item.radius * 2
                  obj.radius = item.radius
                }
                this.shapeArray.push(obj)
              }
            })

            if (this.shapeArray.length > 0) {
              this.shapeArray.forEach((item) => {
                new Promise((resolve, reject) => {
                  this.getDomById(resolve, item.id, 1)
                }).then((res) => {
                  this.draw(res, item)
                })
              })
            }
            if (this.lineArray.length > 0) {
              this.lineArray.forEach((item) => {
                new Promise((resolve, reject) => {
                  this.getDomById(resolve, item.id, 1)
                }).then((res) => {
                  this.draw(res, item)
                })
              })
            }
          }
        }

        this.loadRightWidget()
        this.initCanvas()
        this.shapeArray.forEach((item, index) => {
          if (nowId && item.id == nowId) {
            this.isCheck = item
            this.showCheck = true
            this.rightVNode.forEach((v, index) => {
              if (v.type == this.isCheck.type) {
                this.rightVNode_now = v.type
              }
            })
            this.showRightValue = true
            let _that = null
            this.rightVNode.forEach((item, index) => {
              if (item.type == this.rightVNode_now) {
                _that = item.value
              }
            })
            if (this.isCheck.value) {///设置值
              for (let key in this.isCheck.value) {
                let vnode = component.getVNode(_that, key, false);
                if (vnode) {
                  if (this.isCheck.data) {
                    if (this.isCheck.data[key].length > 0) {
                      vnode.data = JSON.parse(JSON.stringify(this.isCheck.data[key]))
                    }
                  }
                  if (vnode.multiple) {
                    // debugger
                    // console.log(this.isCheck)
                    if (Object.prototype.toString.call(this.isCheck.value[key]) === '[object Array]') {
                      // vnode.value = JSON.parse(this.isCheck.value[key])
                      vnode.value = JSON.parse(JSON.stringify(this.isCheck.value[key]))
                    } else {
                      vnode.value = []
                    }
                  } else {
                    vnode.value = JSON.parse(JSON.stringify(this.isCheck.value[key]))
                  }
                }
              }
            } else {
              let objData = this.getRightValue()
              for (let keys in objData) {
                let vnode = component.getVNode(_that, keys, false);
                if (vnode) {
                  vnode.value = vnode.multiple ? [] : null;
                }
              }
            }
          }
        })
        this.beginLister()
        let iconBtnDom = this.$refs.iconBtn
        if (iconBtnDom.length == this.widget.length) {
          for (let i = 0; i < iconBtnDom.length; i++) {
            this.$w.load_widget(this, this.widget[i].icon, iconBtnDom[i])
          }
        }
      })
    },

    methods: {
      setCenterWidth(width) {
        this.rightWidth = width
        this.$refs.center_box.style.width = 'calc(100% - ' + (120 + this.rightWidth) + 'px)'
      },
      widthMoveStar(e) {
        this.$refs.flowBox.style.cursor = 'w-resize'
        this.widthMovePlace = {
          x: e.pageX,
          width: JSON.parse(JSON.stringify(this.rightWidth))
        }
      },
      widthMoveAction(e) {
        if (this.widthMovePlace) {
          if (!this.allWidth) {
            this.allWidth = this.$refs.flowBox.clientWidth
          }
          let width = this.widthMovePlace.x - e.pageX + this.widthMovePlace.width
          if (width >= this.allWidth * 0.4) {
            width = this.allWidth * 0.4
          }
          if (width <= this.allWidth * 0.1) {
            width = this.allWidth * 0.1
          }
          this.setCenterWidth(width)
        }
      },
      /*
      * 开启页面的事假监听
      * */
      beginLister() {
        window.addEventListener('mouseup', this.mouseupAction)
        window.addEventListener('keydown', this.keydownAction)
        window.addEventListener('mousemove', this.widthMoveAction)
        this.$refs.center_box.addEventListener('click', this.mousedownAction)
        this.$refs.center_box.addEventListener('mousemove', this.mousemoveAction)
      },
      /*
      *关闭页面的监听
      * */
      endLister() {

      },

      getRightValue() {
        let result = null
        let data = {}
        this.rightVNode.forEach((item, index) => {
          if (item.type == this.rightVNode_now) {
            result = component.getChildrenValue(item.value)
            if (result) {
              for (let keys in result) {
                let dataArry = []
                if (result[keys]) {
                  if (result[keys].indexOf('[') === 0) { //数组value 转换
                    result[keys] = JSON.parse(result[keys])
                  }
                  let nodeNow = component.getVNode(item.value, keys, false)
                  if (nodeNow.sourceData && nodeNow.multiple) {
                    // console.log(nodeNow.data)
                    if (Object.prototype.toString.call(result[keys]) === '[object Array]') {
                      result[keys].forEach((item2, index2) => {
                        for (let i = 0; i < nodeNow.sourceData.length; i++) {
                          if (nodeNow.sourceData[i][0] == item2) {
                            dataArry.push(nodeNow.sourceData[i])
                          }
                        }
                      })
                    }
                  }

                }
                data[keys] = dataArry
              }
            }
          }
        })
        // console.log(data['approval_user'])
        return {result: result, data: data}
      },

      loadRightWidget() {
        this.widget.forEach((item, index) => {
          let data = item.data
          if (data) {
            let res = this.$w.load_widget(this, data, this.$refs.insertDom[index], 'append')
            this.rightVNode.push({type: item.type, value: res})
          }
        })
      },

      keydownAction(e) {
        //键盘输入事件
        if (this.showCheck) {
          if (e.code == 'Delete') {
            if (e.target.nodeName == 'INPUT' || e.target.nodeName == 'TEXTAREA') {
              return;
            }
            let index_shape = null
            this.shapeArray.forEach((item, index) => {
              if (item.id == this.isCheck.id) {
                index_shape = index
              }
            })
            let resultList = []
            this.lineArray.forEach((item, index) => {
              let isDel = false
              if (item.s_id) {
                if (item.s_id.split('_')[0] == this.isCheck.id) {
                  isDel = true
                }
              }
              if (item.e_id) {
                if (item.e_id.split('_')[0] == this.isCheck.id) {
                  isDel = true
                }
              }
              if (!isDel) {
                resultList.push(item)
              }
            })
            this.lineArray = JSON.parse(JSON.stringify(resultList))

            if (index_shape !== null) {
              this.isEdit = false
              this.editItem = null
              this.shapeArray.splice(index_shape, 1)
              this.isChoose = null
              this.showCheck = null
              this.nowLine = null
              this.beginPlace = null
              this.beginMovePlace = null
              this.shapeContour = null
              this.showRightValue = false
            }
          }
        }

      },

      /*
      * 鼠标抬起事件
      * */
      mouseupAction() {
        if (this.widthMovePlace) {
          this.widthMovePlace = null
          this.$refs.flowBox.style.cursor = 'auto'
        }
        this.isChoose = null
        this.nowLine = null
        this.beginPlace = null
        this.link_point_canvas.show = false
        this.beginMovePlace = null

        let result = []
        this.lineArray.forEach((item, index) => {
          if (item.e_id && item.s_id) {
            result.push(item)
          }
        })
        this.lineArray = result

      },
      /*
      * 鼠标点击事件
      * */
      mousedownAction(e) {
        if (this.isCheck) {
          let isNow = false
          e.path.forEach((item) => {
            if (item.id == this.isCheck.id) {
              isNow = true
            }
          })
          if (e.path[0].className == 'center_box') {
            isNow = true
          }
          if (!isNow) {  //不是当前点击的图形，关闭显示
            let result = this.getRightValue()
            this.isCheck.value = JSON.parse(JSON.stringify(result.result))
            this.isCheck.data = JSON.parse(JSON.stringify(result.data))
            // this.shapeArray.forEach((item) => {
            //   if (item.id == this.isCheck.id) {
            //     item.value = JSON.parse(JSON.stringify(this.isCheck.value))
            //   }
            // })
            this.showRightValue = false
          }
        }
        // if (e.button == 2) {
        //   if (e.target.className == 'drawContent') {
        //     this.showCheck = false
        //   }
        //
        // }
        if (e.target.className == 'drawContent') {
          this.showCheck = false
        }
      },

      /*
      * 鼠标移动事件
      * */

      mousemoveAction(e) {
        if (this.beginMovePlace && this.isCheck) {
          this.shapeScale(e)
          return;
        }
        if (this.isChoose) { ///拖动图形 记录初始位置
          if (!this.beginPlace) { ///存在选中但是没有位置，为新增的图形
            this.beginPlace = {
              x: e.pageX,
              y: e.pageY,
              x_choose: e.offsetX - this.isChoose.width / 2,
              y_choose: e.offsetY - this.isChoose.height / 2
            }
            this.isChoose.x = e.offsetX - this.isChoose.width / 2
            this.isChoose.y = e.offsetY - this.isChoose.height / 2
          } else {
            let moveX = this.beginPlace.x_choose * 1 + (e.pageX - this.beginPlace.x) * 1 - this.isChoose.x
            let moveY = this.beginPlace.y_choose * 1 + (e.pageY - this.beginPlace.y) * 1 - this.isChoose.y
            this.resetLine(this.isChoose.id, moveX, moveY)
            this.isChoose.x = this.beginPlace.x_choose * 1 + (e.pageX - this.beginPlace.x) * 1
            this.isChoose.y = this.beginPlace.y_choose * 1 + (e.pageY - this.beginPlace.y) * 1

          }
        }

        if (this.nowLine) {  //画线
          if (e.target.className != 'link_point_canvas') {
            this.link_point_canvas.show = false
          }
          if (this.link_point_canvas.show) { //鼠标在范围点上
            return;
          }
          this.moveLineAction(e)
        }

        if (e.target.className.indexOf('shape_canvas_') != -1) { ///移动到图形
          let data = this.shapeArray[Number(e.target.className.split('shape_canvas_')[1])]
          this.shapeMouseenter(e, data)//显示圆圈
          if (this.nowLine) {
            if (data.id == this.nowLine.data.s_id.split('_')[0]) {  //结束位置为当前图形
              return
            }
            let pointList = [
              {
                x: data.width / 2,
                y: 0
              },
              {
                x: data.width,
                y: data.height / 2
              },
              {
                x: data.width / 2,
                y: data.height
              },
              {
                x: 0,
                y: data.height / 2
              },
            ]
            pointList.forEach((item, index) => {
              if (Math.pow(e.offsetX - item.x - 10, 2) + Math.pow(e.offsetY - item.y - 10, 2) <= 100) {
                this.link_point_canvas.x = data.x + item.x - 2
                this.link_point_canvas.y = data.y + item.y - 2
                this.link_point_canvas.z = data.z
                this.setShapeContour(data)  ///显示圆圈
                this.link_point_canvas.show = true
                this.moveLineAction({
                  pageX: e.pageX - (e.offsetX - item.x - 10),
                  pageY: e.pageY - (e.offsetY - item.y - 10)
                }, data.id + '_' + index)
              }
            })
          }
        }
      },


      zoomClick(type, e) {
        this.beginMovePlace = {
          x: e.pageX,
          y: e.pageY,
          type: type
        }
      },

      shapeScale(e) {  //缩放
        if (this.isCheck.type == 'round') {
          return
        }
        this.shapeContour = null
        let type = this.beginMovePlace.type
        //1 左上 2右上 3右下 4左下
        //重绘关联线段
        let moveX = e.pageX - this.beginMovePlace.x
        let moveY = e.pageY - this.beginMovePlace.y
        this.beginMovePlace.x = e.pageX
        this.beginMovePlace.y = e.pageY
        switch (type) {
          case 1:
            this.isCheck.x += moveX
            this.isCheck.y += moveY
            this.isCheck.width -= moveX
            this.isCheck.height -= moveY
            break;
          case 2:
            this.isCheck.y += moveY
            this.isCheck.width += moveX
            this.isCheck.height -= moveY
            break;
          case 3:
            this.isCheck.width += moveX
            this.isCheck.height += moveY
            break;
          case 4:
            this.isCheck.x += moveX
            this.isCheck.width -= moveX
            this.isCheck.height += moveY
            break;
          default:
            break;
        }
        //重绘图形
        if (this.isCheck.type == 'rectangle') {
          new Promise((resolve, reject) => {
            this.getDomById(resolve, this.isCheck.id, 1)
          }).then((res) => {
            this.draw(res, this.isCheck)
          })
          this.resetLine(this.isCheck.id, moveX, moveY, type)
        }
      },

      /*
      * 移动图形时重绘线
      * */
      resetLine(id, x, y, isScale = false) {
        if (this.lineArray.length > 0) {
          this.lineArray.forEach((item, index) => {
            let originX = x
            let originY = y
            let s_id = ''
            let e_id = ''
            let s_id_index = -1
            let e_id_index = -1
            if (item.s_id) {
              s_id = item.s_id.split('_')[0]
              s_id_index = Number(item.s_id.split('_')[1])
            }
            if (item.e_id) {
              e_id = item.e_id.split('_')[0]
              e_id_index = Number(item.e_id.split('_')[1])
            }
            if (s_id == id || e_id == id) { ///点在图形上
              if (isScale) {
                //缩放时要根据点位重置x y
                if (s_id == id) { ///起始点在图形上
                  switch (isScale) {
                    case 1:
                      //左上角缩放
                      if (s_id_index == 0) {
                        originX = originX / 2
                      }
                      if (s_id_index == 1) {
                        originX = 0
                        originY = originY / 2
                      }
                      if (s_id_index == 2) {
                        originX = originX / 2
                        originY = 0
                      }
                      if (s_id_index == 3) {
                        originY = originY / 2
                      }
                      break;
                    case 2:
                      //右上角缩放
                      if (s_id_index == 0) {
                        originX = originX / 2
                      }
                      if (s_id_index == 1) {
                        originY = originY / 2
                      }
                      if (s_id_index == 2) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (s_id_index == 3) {
                        originX = 0
                        originY = originY / 2
                      }
                      break;
                    case 3:
                      //右下角缩放
                      if (s_id_index == 0) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (s_id_index == 1) {
                        originY = originY / 2
                      }
                      if (s_id_index == 2) {
                        originX = originX / 2
                      }
                      if (s_id_index == 3) {
                        originX = 0
                        originY = originY / 2
                      }
                      break;
                    case 4:
                      //左下角缩放
                      if (s_id_index == 0) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (s_id_index == 1) {
                        originX = 0
                        originY = originY / 2
                      }
                      if (s_id_index == 2) {
                        originX = originX / 2
                      }
                      if (s_id_index == 3) {
                        originY = originY / 2
                      }
                      break;
                    default:
                      break;
                  }
                } else {///结束点在图形上
                  switch (isScale) {
                    case 1:
                      //左上角缩放
                      if (e_id_index == 0) {
                        originX = originX / 2
                      }
                      if (e_id_index == 1) {
                        originX = 0
                        originY = originY / 2
                      }
                      if (e_id_index == 2) {
                        originX = originX / 2
                        originY = 0
                      }
                      if (e_id_index == 3) {
                        originY = originY / 2
                      }
                      break;
                    case 2:
                      //右上角缩放
                      if (e_id_index == 0) {
                        originX = originX / 2
                      }
                      if (e_id_index == 1) {
                        originY = originY / 2
                      }
                      if (e_id_index == 2) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (e_id_index == 3) {
                        originX = 0
                        originY = originY / 2
                      }
                      break;
                    case 3:
                      //右下角缩放
                      if (e_id_index == 0) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (e_id_index == 1) {
                        originY = originY / 2
                      }
                      if (e_id_index == 2) {
                        originX = originX / 2
                      }
                      if (e_id_index == 3) {
                        originX = 0
                        originY = originY / 2
                      }
                      break;
                    case 4:
                      //左下角缩放
                      if (e_id_index == 0) {
                        originY = 0
                        originX = originX / 2
                      }
                      if (e_id_index == 1) {
                        originX = 0
                        originY = originY / 2
                      }
                      if (e_id_index == 2) {
                        originX = originX / 2
                      }
                      if (e_id_index == 3) {
                        originY = originY / 2
                      }
                      break;
                    default:
                      break;
                  }
                }
              }
              if (s_id == id) {
                item.origin_x += originX
                item.origin_y += originY
              }
              let newx = item.pos[0][0] + originX
              let newy = item.pos[0][1] + originY
              item.width = Math.abs(newx - item.pos[item.pos.length - 1][0])
              item.height = Math.abs(newy - item.pos[item.pos.length - 1][1])
              let star_p = item.pos[0]
              let end_p = item.pos[item.pos.length - 1]
              if (e_id == id) {
                newx = item.pos[item.pos.length - 1][0] + originX
                newy = item.pos[item.pos.length - 1][1] + originY
                item.width = Math.abs(newx - item.pos[0][0])
                item.height = Math.abs(newy - item.pos[0][1])
                star_p = item.pos[item.pos.length - 1]
                end_p = item.pos[0]
              }

              if (star_p[0] > end_p[0] && newx > end_p[0]) {
                //x定位不用移动
              } else {
                if (star_p[0] < end_p[0] && newx > end_p[0]) {
                  item.x = item.x + originX - item.width
                }
                if (newx < end_p[0] && star_p[0] > end_p[0]) {
                  item.x = item.x - item.width
                }
                if (star_p[0] <= end_p[0] && newx <= end_p[0]) {
                  item.x = item.x + originX
                }
              }
              if (star_p[1] > end_p[1] && newy > end_p[1]) {
                //y定位不用移动
              } else {
                if (star_p[1] < end_p[1] && newy > end_p[1]) {
                  item.y = item.y + originY - item.height
                  //开始小，结束大
                  // console.log(1)
                }
                if (newy < end_p[1] && star_p[1] > end_p[1]) {
                  item.y = item.y - item.height
                  //开始大,结束小
                  // console.log(2)
                }
                if (star_p[1] <= end_p[1] && newy <= end_p[1]) {
                  item.y = item.y + originY
                  ///一直小
                  // console.log(3)
                }
              }

              if (s_id == id) {
                item.pos[0][0] = item.pos[0][0] + originX
                item.pos[0][1] = item.pos[0][1] + originY
              } else {
                item.pos[item.pos.length - 1][0] = item.pos[item.pos.length - 1][0] + originX
                item.pos[item.pos.length - 1][1] = item.pos[item.pos.length - 1][1] + originY
              }
              //重绘图形
              // console.log(item)
              // let data = JSON.parse(JSON.stringify(item))
              if (item.e_id) {
                this.draw(null, item)
              } else {
                new Promise((resolve, reject) => {
                  this.getDomById(resolve, item.id, 1)
                }).then((res) => {
                  this.draw(res, item)
                })
              }

            }

          })

        }
      },

      moveLineAction(e, e_id) {
        if (Math.abs(e.pageX - this.nowLine.data.pos[0][0]) > 10 || Math.abs(e.pageY - this.nowLine.data.pos[0][1]) > 10) {
          if (this.nowLine.data.pos.length == 1) {
            //新增新线
            this.nowLine.data.pos.push(
              [
                e.pageX,
                e.pageY
              ]
            )
          } else {
            this.nowLine.data.pos[this.nowLine.data.pos.length - 1][0] = e.pageX
            this.nowLine.data.pos[this.nowLine.data.pos.length - 1][1] = e.pageY
          }
          if (e_id) {  ///结束位置在图形标点位置
            this.nowLine.data.e_id = e_id
          } else {     //结束位置不在图形标点位置
            this.nowLine.data.e_id = ''
          }
          this.nowLine.data.width = Math.abs(e.pageX - this.nowLine.data.pos[0][0])
          this.nowLine.data.height = Math.abs(e.pageY - this.nowLine.data.pos[0][1])

          if (e.pageX - this.nowLine.data.pos[0][0] < 0) {
            this.nowLine.data.x = this.nowLine.data.origin_x - this.nowLine.data.width
          } else {
            this.nowLine.data.x = this.nowLine.data.origin_x
          }
          if (e.pageY - this.nowLine.data.pos[0][1] < 0) {
            this.nowLine.data.y = this.nowLine.data.origin_y - this.nowLine.data.height
          } else {
            this.nowLine.data.y = this.nowLine.data.origin_y
          }
          ///开始画线
          new Promise((resolve, reject) => {
            this.getDomById(resolve, this.nowLine.data.id, 1)
          }).then((res) => {
            this.draw(res, this.nowLine.data)
          })
        }
      },

      shapeMouseenter(e, data) {
        ///判断是否进入形状内，显示
        if (data.type == 'round') {
          if (this.checkInRound(e.offsetX, e.offsetY, data)) {
            ///在圆环内部
            this.setShapeContour(data)
          } else {
            this.shapeContour = null
          }
        } else if (data.type == 'rectangle') {
          ///在矩形内部
          if (this.checkInRectangle(e.offsetX, e.offsetY, data)) {
            this.setShapeContour(data)
          } else {
            this.shapeContour = null
          }
        }
      },

      setShapeContour(data) {
        this.shapeContour = {
          left: data.x + 10,
          top: data.y + 10,
          point: [
            {
              x: data.width / 2,
              y: 0
            },
            {
              x: data.width,
              y: data.height / 2
            },
            {
              x: data.width / 2,
              y: data.height
            },
            {
              x: 0,
              y: data.height / 2
            },
          ],
          z: data.z,
          id: data.id
        }
      },

      checkInRound(x, y, data) {
        let a = data.width / 2
        let b = data.height / 2
        let result = Math.pow(x - a - 10, 2) / Math.pow(a, 2) + Math.pow(y - b - 10, 2) / Math.pow(b, 2)
        if (result < 1) {
          return true
        } else {
          return false
        }
      },

      checkInRectangle(x, y, data) {
        let flag1 = false
        let flag2 = false
        if (x > 10 && x < data.width + 10) {
          flag1 = true
        }
        if (y > 10 && y < data.height + 10) {
          flag2 = true
        }
        if (flag1 && flag2) {
          return true
        } else {
          return false
        }
      },

      initCanvas() {
        let canvas = this.$refs.myCanvas;
        if (canvas.getContext) {
          let ctx = canvas.getContext('2d');

        } else {
          /*
          * 浏览器不支持canvas
          * */
        }
      },

      getDomById(resolve, id, type) {
        let result = null
        let index = this.timer.length
        let timer = window.requestAnimationFrame(() => {
          result = document.getElementById(id)
          if (result) {
            cancelAnimationFrame(this.timer[index])
            if (type == 1) {
              result = result.getElementsByTagName('canvas')[0].getContext('2d')
              resolve(result)
            } else {
              resolve(result)
            }
          }
        })
        this.timer.push(timer)
      },
      /*
      * 左边icon选中事件
      * */
      chooseIcon(item, type, event) {
        if (type == 1) {
          this.textValue = ''
          // 新建的图形
          let obj = null
          if (item.type === 'round') {
            obj = JSON.parse(JSON.stringify(this.defaultRound))
            obj.id = 'round' + common.allocateId(6, false)
          } else if (item.type == 'rectangle') {
            obj = JSON.parse(JSON.stringify(this.defaultRect))
            obj.id = 'rectangle' + common.allocateId(6, false)
          } else if (item.type == 'connect_line') {
            // this.chooseLine = true
          }
          if (this.chooseLine) {
            return
          }
          obj.z = this.shapeArray.length * 3 + 1
          this.shapeArray.push(obj)
          new Promise((resolve, reject) => {
            this.getDomById(resolve, obj.id, 1)
          }).then((res) => {
            this.draw(res, obj)
            this.isChoose = obj
            this.isCheck = obj
            this.showCheck = true
            this.rightVNode.forEach((v, index) => {
              if (v.type == this.isCheck.type) {
                this.rightVNode_now = v.type
              }
            })
            this.showRightValue = true
            let _that = null
            this.rightVNode.forEach((item, index) => {
              if (item.type == this.rightVNode_now) {
                _that = item.value
              }
            })
            let objData1 = this.getRightValue().result
            for (let keys in objData1) {
              let vnode1 = component.getVNode(_that, keys, false);
              if (vnode1) {
                vnode1.value = vnode1.multiple ? [] : null;
                if (vnode1.multiple) {
                  vnode1.data = []
                }
              }
            }
          })
        } else if (type == 2) {
          ///点击现有的图形
          this.shapeArray.forEach((items) => {
            if (item.id == items.id) {
              this.beginPlace = {
                x: event.pageX,
                y: event.pageY,
                x_choose: items.x,
                y_choose: items.y,
              }
              this.isChoose = item
              this.showCheck = true
            }
            if (this.isCheck) {  //上一个图形存在
              if (this.isCheck.id == items.id) {
                let result = this.getRightValue().result
                items.value = result
                items.data = this.getRightValue().data
              }
            }
          })
          this.isCheck = this.isChoose
          this.rightVNode.forEach((v, index) => {
            if (v.type == this.isCheck.type) {
              this.rightVNode_now = v.type
            }
          })

          this.showRightValue = true
          let _that = null
          this.rightVNode.forEach((item, index) => {
            if (item.type == this.rightVNode_now) {
              _that = item.value
            }
          })
          if (this.isCheck.value) {///设置值
            for (let key in this.isCheck.value) {
              let vnode = component.getVNode(_that, key, false);
              if (vnode) {
                if (vnode.setBlur) {
                  vnode.setBlur()
                }
                if (vnode.multiple) {
                  if (Object.prototype.toString.call(this.isCheck.value[key]) === '[object Array]') {
                    vnode.value = []
                    vnode.value = JSON.parse(JSON.stringify(this.isCheck.value[key]))
                  } else {
                    vnode.value = []
                  }
                } else {
                  vnode.value = JSON.parse(JSON.stringify(this.isCheck.value[key]))
                }
                if (this.isCheck.data) {
                  // console.log(this.isCheck.data)
                  if (this.isCheck.data[key].length > 0 && Object.prototype.toString.call(this.isCheck.data[key]) === '[object Array]') {
                    // console.log(this.isCheck.data)
                    vnode.data = []
                    let newData = JSON.parse(JSON.stringify(this.isCheck.data[key]))
                    newData.forEach((item) => {
                      vnode.data.push(JSON.parse(JSON.stringify(item)))
                    })
                  } else {
                    vnode.data = []
                  }
                } else {
                  vnode.data = []
                }
              }
            }
          } else {
            let objData = this.getRightValue().result
            for (let keys in objData) {
              let vnode = component.getVNode(_that, keys, false);
              if (vnode) {
                vnode.value = vnode.multiple ? [] : null;
              }
            }
          }
        }
      },

      getShapeDataById(id) {
        let result = null
        this.shapeArray.forEach((item) => {
          if (item.id == id) {
            result = JSON.parse(JSON.stringify(item))
          }
        })
        return result
      },

      /*
      * 画线圆点点击事件
      *
      * */
      creatLine(item, e, index, id) {
        let pageTop = Math.ceil(e.target.getBoundingClientRect().top + 5)
        let pageLeft = Math.ceil(e.target.getBoundingClientRect().left + 5)
        let obj = {
          pos: [
            [pageLeft, pageTop]
          ],
          x: this.shapeContour.left + item.x,
          y: this.shapeContour.top + item.y,
          origin_x: JSON.parse(JSON.stringify(this.shapeContour.left + item.x)),
          origin_y: JSON.parse(JSON.stringify(this.shapeContour.top + item.y)),
          type: 'connect_line',
          width: 0,
          height: 0
        }
        obj.id = 'line' + common.allocateId(6, true)
        obj.s_id = id + '_' + index
        this.lineArray.push(obj)
        new Promise((resolve, reject) => {
          this.getDomById(resolve, obj.id, 1)
        }).then((res) => {
          this.nowLine = {
            ctx: res,
            data: obj
          }
        })
        ///新建一条线
      },

      draw(ctx, item) {
        switch (item.type) {
          case 'round':
            this.drawRound(ctx, item)
            break;
          case 'rectangle':
            this.drawRect(ctx, item)
            break;
          case 'connect_line':
            this.drawConnectLine(ctx, item)
            break
        }
      },
      /*
      *绘制圆角矩形(或者矩形)
      *
      * params:{canvas2d上下文对象，基本属性，基本样式}
      */
      drawRect(ctx, baseProperty, baseStyle = {}) {
        //根据拖动坐标计算位置 计算左上角起点位置
        /*
        * x,y左上角坐标，宽度高度，圆角
        * */
        function roundedRect(ctx, x, y, width = 80, height = 80, radius = 0, color = '#000000', type = 'stroke') {
          ctx.clearRect(0, 0, width + 20, height + 20)
          ctx.beginPath()
          ctx.moveTo(x, y + radius)
          ctx.lineTo(x, y + height - radius)
          ctx.quadraticCurveTo(x, y + height, x + radius, y + height)
          ctx.lineTo(x + width - radius, y + height)
          ctx.quadraticCurveTo(x + width, y + height, x + width, y + height - radius)
          ctx.lineTo(x + width, y + radius)
          ctx.quadraticCurveTo(x + width, y, x + width - radius, y)
          ctx.lineTo(x + radius, y)
          ctx.quadraticCurveTo(x, y, x, y + radius)
          ctx[type + 'Style'] = color
          ctx.closePath()
          ctx[type]()
          ctx.fillStyle = '#ffffff'
          ctx.fill()
          if (baseProperty.label) {
            ctx.fillStyle = "#000";
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            let line = []
            let str = ''
            if (width < ctx.measureText(baseProperty.label).width) {
              for (let i = 0; i < baseProperty.label.length; i++) {
                str += baseProperty.label[i]
                if (width - 8 < ctx.measureText(str).width) {
                  line.push({text: str.substr(0, str.length - 1)})
                  str = baseProperty.label[i]
                } else if (i == baseProperty.label.length - 1) {
                  line.push({text: str})
                }
              }
            } else {
              //不存在换行
              line.push({text: baseProperty.label})
            }
            let y_init = (height + 10 - line.length * 18) / 2
            line.forEach((item, index) => {
              ctx.fillText(item.text, (width + 20) / 2, y_init + (index + 1) * 18);
            })

          }
        }

        roundedRect(ctx, 10, 10, baseProperty.width, baseProperty.height, baseStyle.radius, baseStyle.color, baseStyle.type)
      },


      drawRound(ctx, baseProperty, baseStyle = {}) {
        function roundedRect(ctx, x, y, width = 100, height = 100, radius = width / 2, color = '#000000', type = 'stroke') {
          ctx.clearRect(0, 0, width + 20, height + 20)
          ctx.beginPath()
          ctx.arc(x + width / 2, y + height / 2, radius, 0, Math.PI * 2);
          ctx[type + 'Style'] = color
          ctx.closePath()
          ctx[type]()
          ctx.fillStyle = '#ffffff'
          ctx.fill()
          if (baseProperty.label) {
            ctx.fillStyle = "#000";
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            let line = []
            let str = ''
            if (width < ctx.measureText(baseProperty.label).width) {
              for (let i = 0; i < baseProperty.label.length; i++) {
                str += baseProperty.label[i]
                if (width < ctx.measureText(str).width) {
                  line.push({text: str.substr(0, str.length - 1)})
                  str = baseProperty.label[i]
                } else if (i == baseProperty.label.length - 1) {
                  line.push({text: str})
                }
              }
            } else {
              //不存在换行
              line.push({text: baseProperty.label})
            }
            let y_init = (height + 10 - line.length * 18) / 2
            line.forEach((item, index) => {
              ctx.fillText(item.text, (width + 20) / 2, y_init + (index + 1) * 18);
            })

          }
        }

        roundedRect(ctx, 10, 10, baseProperty.width, baseProperty.height, baseProperty.radius, baseStyle.color, baseStyle.type)
      },

      drawConnectLine(ctx, baseProperty) {
        let baseX = baseProperty.pos[0][0]
        let baseY = baseProperty.pos[0][1]
        let centerList = []
        let direction = ''
        let start_point = JSON.parse(JSON.stringify(baseProperty.pos[0]))
        let end_point = JSON.parse(JSON.stringify(baseProperty.pos[baseProperty.pos.length - 1]))
        let s_index = 1  //默认左右方向
        let pointType = ''
        if (baseProperty.s_id) {
          s_index = baseProperty.s_id.split('_')[1]
        }
        if (baseProperty.e_id) {  //结束点为关联点
          let e_Index = Number(baseProperty.e_id.split('_')[1])
          let endShape = this.getShapeDataById(baseProperty.e_id.split('_')[0])
          let sShape = this.getShapeDataById(baseProperty.s_id.split('_')[0])
          let pointArray = []
          let point_d = ''
          baseProperty.width = Math.abs(start_point[0] - end_point[0])
          baseProperty.height = Math.abs(start_point[1] - end_point[1])
          pointArray.push(start_point)
          if (s_index == 0) { ///起始点在上面
            switch (e_Index) {
              case 0:
                //结束点在上，箭头朝下
                baseProperty.height += 30
                point_d = 'bottom'
                if (start_point[1] > end_point[1]) {  //结束位置在上
                  baseProperty.y = baseProperty.origin_y - baseProperty.height
                  pointArray.push([start_point[0], end_point[1] - 30])
                  pointArray.push([end_point[0], end_point[1] - 30])
                  pointArray.push([end_point[0], end_point[1] - 20])
                } else {  //结束点在下
                  baseProperty.y = baseProperty.origin_y - 30
                  pointArray.push([start_point[0], start_point[1] - 30])
                  pointArray.push([end_point[0], start_point[1] - 30])
                  pointArray.push([end_point[0], end_point[1] - 20])
                }
                break;
              case 1:
                //结束点在右，箭头朝左
                point_d = 'left'
                if (start_point[0] < end_point[0]) {///结束在右
                  baseProperty.width += 30
                  if (end_point[1] + endShape.height / 2 < start_point[1]) {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    let h_space = start_point[1] - endShape.height / 2 - end_point[1]
                    h_space = h_space > 60 ? 30 : h_space / 2
                    pointArray.push([start_point[0], start_point[1] - h_space])
                    pointArray.push([end_point[0] + 30, start_point[1] - h_space])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else {
                    let h_space2 = start_point[1] - (end_point[1] - endShape.height / 2 - 30)
                    h_space2 = h_space2 > 30 ? h_space2 : 30
                    baseProperty.y = baseProperty.origin_y - h_space2
                    baseProperty.height += h_space2
                    pointArray.push([start_point[0], start_point[1] - h_space2])
                    pointArray.push([end_point[0] + 30, start_point[1] - h_space2])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  }
                } else {///结束在左
                  if (end_point[1] >= start_point[1]) {
                    baseProperty.height += 30
                    baseProperty.y = baseProperty.origin_y - 30
                    pointArray.push([start_point[0], start_point[1] - 30])
                    pointArray.push([end_point[0] + 30, start_point[1] - 30])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    pointArray.push([start_point[0], end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  }
                }
                break;
              case 2:
                point_d = 'top'
                //结束点在下 箭头向上
                if (start_point[1] - end_point[1] >= 30) {
                  baseProperty.y = baseProperty.origin_y - baseProperty.height
                  pointArray.push([start_point[0], end_point[1] + 30])
                  pointArray.push([end_point[0], end_point[1] + 30])
                  pointArray.push([end_point[0], end_point[1] + 20])
                } else {
                  baseProperty.height += 60
                  baseProperty.y = baseProperty.origin_y - 30
                  pointArray.push([start_point[0], start_point[1] - 30])
                  pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, start_point[1] - 30])
                  pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, end_point[1] + 30])
                  pointArray.push([end_point[0], end_point[1] + 30])
                  pointArray.push([end_point[0], end_point[1] + 20])
                }

                break;
              case 3:
                point_d = 'right'
                //结束点在左 箭头向右
                if (start_point[0] < end_point[0]) {///结束在右
                  if (end_point[1] >= start_point[1]) {
                    baseProperty.height += 30
                    baseProperty.y = baseProperty.origin_y - 30
                    pointArray.push([start_point[0], start_point[1] - 30])
                    pointArray.push([end_point[0] - 30, start_point[1] - 30])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  } else {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    baseProperty.x = baseProperty.origin_x
                    pointArray.push([start_point[0], end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  }
                } else {///结束在左

                  baseProperty.width += 30
                  if (end_point[1] + endShape.height / 2 < start_point[1]) {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    let h_space3 = start_point[1] - endShape.height / 2 - end_point[1]
                    h_space3 = h_space3 > 60 ? 30 : h_space3 / 2
                    pointArray.push([start_point[0], start_point[1] - h_space3])
                    pointArray.push([end_point[0] - 30, start_point[1] - h_space3])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  } else {
                    let h_space4 = start_point[1] - (end_point[1] - endShape.height / 2 - 30)
                    h_space4 = h_space4 > 30 ? h_space4 : 30
                    baseProperty.y = baseProperty.origin_y - h_space4
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    baseProperty.height += h_space4
                    pointArray.push([start_point[0], start_point[1] - h_space4])
                    pointArray.push([end_point[0] - 30, start_point[1] - h_space4])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  }
                }
                break;
            }
          }
          if (s_index == 1) {
            switch (e_Index) {
              case 0:
                point_d = 'bottom'
                if (end_point[0] > start_point[0]) {
                  if (end_point[1] < start_point[1]) {
                    baseProperty.height += 30
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    let h_space = end_point[0] - endShape.width / 2 - start_point[0]
                    h_space = h_space > 60 ? 30 : h_space / 2
                    pointArray.push([start_point[0] + h_space, start_point[1]])
                    pointArray.push([start_point[0] + h_space, end_point[1] - 30])
                    pointArray.push([end_point[0], end_point[1] - 30])
                    pointArray.push([end_point[0], end_point[1] - 20])
                  } else {
                    if (end_point[1] < start_point[1] + 30) {
                      baseProperty.height += 30
                      baseProperty.y = baseProperty.origin_y - 30
                      pointArray.push([start_point[0] + 30, start_point[1]])
                      pointArray.push([start_point[0] + 30, start_point[1] - 30])
                      pointArray.push([end_point[0], start_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      baseProperty.y = baseProperty.origin_y
                      baseProperty.x = baseProperty.origin_x
                      pointArray.push([end_point[0], start_point[1]])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    }
                  }

                } else {
                  baseProperty.width += 30
                  if (end_point[1] < start_point[1] + sShape.height / 2 + 30) {
                    let h_space1 = end_point[1] - (start_point[1] - sShape.height / 2)
                    h_space1 = h_space1 <= 0 ? 30 : end_point[1] - (start_point[1] - sShape.height / 2) - 30
                    if (end_point[1] - (start_point[1] - sShape.height / 2) < 0) {
                      baseProperty.height += 30
                      baseProperty.y = baseProperty.origin_y - baseProperty.height
                      pointArray.push([start_point[0] + 30, start_point[1]])
                      pointArray.push([start_point[0] + 30, end_point[1] - h_space1])
                      pointArray.push([end_point[0], end_point[1] - h_space1])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      if (end_point[1] > start_point[1]) {
                        baseProperty.height = baseProperty.height + sShape.height / 2 + 30
                      } else {
                        baseProperty.height = sShape.height / 2 + 30
                      }
                      baseProperty.y = baseProperty.origin_y - sShape.height / 2 - 30
                      pointArray.push([start_point[0] + 30, start_point[1]])
                      pointArray.push([start_point[0] + 30, start_point[1] - sShape.height / 2 - 30])
                      pointArray.push([end_point[0], start_point[1] - sShape.height / 2 - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    }
                  } else {
                    baseProperty.y = baseProperty.origin_y
                    let h_space2 = end_point[1] - start_point[1] - 30
                    pointArray.push([start_point[0] + 30, start_point[1]])
                    pointArray.push([start_point[0] + 30, start_point[1] + h_space2])
                    pointArray.push([end_point[0], start_point[1] + h_space2])
                    pointArray.push([end_point[0], end_point[1] - 20])
                  }
                }
                break;
              case 1:
                point_d = 'left'
                if (start_point[0] > end_point[0]) {//右边
                  baseProperty.width += 30
                  pointArray.push([start_point[0] + 30, start_point[1]])
                  pointArray.push([start_point[0] + 30, end_point[1]])
                  pointArray.push([end_point[0] + 20, end_point[1]])
                } else {//左边
                  baseProperty.width += 30
                  pointArray.push([end_point[0] + 30, start_point[1]])
                  pointArray.push([end_point[0] + 30, end_point[1]])
                  pointArray.push([end_point[0] + 20, end_point[1]])
                }
                break;
              case 2:
                point_d = 'top'
                if (start_point[1] < end_point[1] + 30) {
                  baseProperty.height += 30
                }
                if (start_point[0] > end_point[0] - endShape.width / 2 - 30) {
                  if (start_point[0] > end_point[0] + endShape.width / 2) {
                    baseProperty.width += 30
                    pointArray.push([start_point[0] + 30, start_point[1]])
                    pointArray.push([start_point[0] + 30, end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  } else {
                    if (start_point[0] > end_point[0]) {
                      baseProperty.width = baseProperty.width + end_point[0] + endShape.width / 2 + 30 - start_point[0]
                    } else {
                      baseProperty.width = baseProperty.width + endShape.width / 2 + 30
                    }
                    pointArray.push([end_point[0] + endShape.width / 2 + 30, start_point[1]])
                    pointArray.push([end_point[0] + endShape.width / 2 + 30, end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  }

                } else {
                  if (start_point[1] > end_point[1] + 30) {
                    pointArray.push([end_point[0], start_point[1]])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  } else {
                    pointArray.push([start_point[0] + 30, start_point[1]])
                    pointArray.push([start_point[0] + 30, end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  }
                }
                break;
              case 3:
                point_d = 'right'
                if (end_point[0] > start_point[0]) {
                  baseProperty.x = baseProperty.origin_x
                  pointArray.push([end_point[0] - (end_point[0] - start_point[0]) / 2, start_point[1]])
                  pointArray.push([end_point[0] - (end_point[0] - start_point[0]) / 2, end_point[1]])
                  pointArray.push([end_point[0] - 20, end_point[1]])
                } else {
                  baseProperty.width += 60
                  baseProperty.x = baseProperty.origin_x - (baseProperty.width - 30)
                  if (start_point[1] > end_point[1]) {
                    pointArray.push([start_point[0] + 30, start_point[1]])
                    pointArray.push([start_point[0] + 30, start_point[1] - baseProperty.height / 2])
                    pointArray.push([end_point[0] - 30, start_point[1] - baseProperty.height / 2])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  } else {
                    pointArray.push([start_point[0] + 30, start_point[1]])
                    pointArray.push([start_point[0] + 30, start_point[1] + baseProperty.height / 2])
                    pointArray.push([end_point[0] - 30, start_point[1] + baseProperty.height / 2])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  }

                }
            }

          }
          if (s_index == 2) {
            switch (e_Index) {
              case 0:
                point_d = 'bottom'
                if (end_point[1] < start_point[1] + 30) {
                  if (end_point[0] - endShape.width / 2 > start_point[0] + sShape.width / 2) {
                    baseProperty.x = baseProperty.origin_x
                    if (end_point[1] < start_point[1]) {
                      baseProperty.height += 60
                      baseProperty.y = baseProperty.origin_y - baseProperty.height + 30
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, start_point[1] + 30])
                      pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      baseProperty.height = 60 - baseProperty.height
                      baseProperty.y = baseProperty.origin_y - (baseProperty.height - 30)
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, start_point[1] + 30])
                      pointArray.push([start_point[0] + (end_point[0] - start_point[0]) / 2, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    }
                  } else {
                    if (end_point[0] > start_point[0]) {
                      baseProperty.height += 60
                      baseProperty.width = baseProperty.width + 30 + sShape.width / 2 + endShape.width / 2
                      baseProperty.x = baseProperty.origin_x - sShape.width / 2 - 30
                      baseProperty.y = baseProperty.origin_y - (baseProperty.height - 30)
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([start_point[0] - sShape.width / 2 - 30, start_point[1] + 30])
                      pointArray.push([start_point[0] - sShape.width / 2 - 30, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      if (end_point[0] + endShape.width / 2 > start_point[0] - sShape.width / 2) {
                        baseProperty.height += 60
                        baseProperty.width = baseProperty.width + 30 + sShape.width / 2
                        baseProperty.y = baseProperty.origin_y - (baseProperty.height - 30)
                        baseProperty.x = baseProperty.origin_x - (baseProperty.width - 30 - sShape.width / 2)
                        pointArray.push([start_point[0], start_point[1] + 30])
                        pointArray.push([start_point[0] + sShape.width / 2 + 30, start_point[1] + 30])
                        pointArray.push([start_point[0] + sShape.width / 2 + 30, end_point[1] - 30])
                        pointArray.push([end_point[0], end_point[1] - 30])
                        pointArray.push([end_point[0], end_point[1] - 20])
                      } else {
                        if (end_point[1] < start_point[1]) {
                          baseProperty.height += 60
                        } else {
                          baseProperty.height = 60 - baseProperty.height
                        }
                        baseProperty.x = baseProperty.origin_x - baseProperty.width
                        baseProperty.y = baseProperty.origin_y - (baseProperty.height - 30)
                        pointArray.push([start_point[0], start_point[1] + 30])
                        pointArray.push([start_point[0] - (start_point[0] - end_point[0]) / 2, start_point[1] + 30])
                        pointArray.push([start_point[0] - (start_point[0] - end_point[0]) / 2, end_point[1] - 30])
                        pointArray.push([end_point[0], end_point[1] - 30])
                        pointArray.push([end_point[0], end_point[1] - 20])
                      }
                    }
                  }

                } else {
                  baseProperty.y = baseProperty.origin_y
                  pointArray.push([start_point[0], end_point[1] - 30])
                  pointArray.push([end_point[0], end_point[1] - 30])
                  pointArray.push([end_point[0], end_point[1] - 20])
                }
                break;
              case 1:
                point_d = 'left'
                if (end_point[1] > start_point[1]) { //结束点在下
                  if (end_point[0] > start_point[0]) {//结束点在右
                    if (end_point[1] - endShape.height / 2 < start_point[1]) {
                      baseProperty.width += 30
                      baseProperty.height = baseProperty.height + endShape.height / 2 + 30
                      pointArray.push([start_point[0], end_point[1] + endShape.height / 2 + 30])
                      pointArray.push([end_point[0] + 30, end_point[1] + endShape.height / 2 + 30])
                      pointArray.push([end_point[0] + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    } else {
                      baseProperty.width += 30
                      let h_s = baseProperty.height - endShape.height / 2
                      h_s = h_s > 60 ? 30 : h_s / 2
                      pointArray.push([start_point[0], start_point[1] + h_s])
                      pointArray.push([end_point[0] + 30, start_point[1] + h_s])
                      pointArray.push([end_point[0] + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    }

                  } else {
                    pointArray.push([start_point[0], end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  }
                } else {
                  // 结束点在上
                  if (end_point[0] < start_point[0] - sShape.width / 2 - 60) {
                    baseProperty.height += 30
                    pointArray.push([start_point[0], start_point[1] + 30])
                    pointArray.push([end_point[0] + 30, start_point[1] + 30])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else {
                    baseProperty.height += 30
                    let w_s = 0
                    if (end_point[0] < start_point[0] + sShape.width / 2) {
                      if (end_point[0] > start_point[0]) {
                        w_s = start_point[0] + sShape.width / 2 + 30 - end_point[0]
                      } else {
                        w_s = sShape.width / 2 + 30
                      }
                      baseProperty.width += w_s
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([start_point[0] + sShape.width / 2 + 30, start_point[1] + 30])
                      pointArray.push([start_point[0] + sShape.width / 2 + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    } else {
                      w_s = 30
                      baseProperty.width += w_s
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0] + 30, start_point[1] + 30])
                      pointArray.push([end_point[0] + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    }

                  }
                }
                break;
              case 2:
                point_d = 'top'
                if (end_point[0] > start_point[0]) {//结束点在右
                  if (end_point[0] > start_point[0] + sShape.width + 30) {
                    baseProperty.height += 30
                    if (end_point[1] < start_point[1]) {
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    } else {
                      pointArray.push([start_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    }
                  } else {
                    baseProperty.height += 30
                    pointArray.push([start_point[0], start_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  }
                } else {
                  if (end_point[0] < start_point[0] - sShape.width - 30) {
                    baseProperty.height += 30
                    if (end_point[1] < start_point[1]) {
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    } else {
                      pointArray.push([start_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    }
                  } else {
                    baseProperty.height += 30
                    pointArray.push([start_point[0], start_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  }
                }
                break;
              case 3:
                point_d = 'right'
                if (end_point[1] > start_point[1]) { ///结束点在下
                  if (end_point[0] > start_point[0]) {
                    baseProperty.x = baseProperty.origin_x
                    pointArray.push([start_point[0], end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  } else {
                    baseProperty.width += 30
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    if (end_point[1] - endShape.height / 2 < start_point[1]) {
                      if (end_point[1] < start_point[1]) {
                        baseProperty.height = endShape.height / 2 + 30 - baseProperty.height
                      } else {
                        baseProperty.height = baseProperty.height + endShape.height / 2 + 30
                      }
                      pointArray.push([start_point[0], end_point[1] + endShape.height / 2 + 30])
                      pointArray.push([end_point[0] - 30, end_point[1] + endShape.height / 2 + 30])
                      pointArray.push([end_point[0] - 30, end_point[1]])
                      pointArray.push([end_point[0] - 20, end_point[1]])
                    } else {
                      pointArray.push([start_point[0], start_point[1] + (end_point[1] - endShape.height / 2 - start_point[1]) / 2])
                      pointArray.push([end_point[0] - 30, start_point[1] + (end_point[1] - endShape.height / 2 - start_point[1]) / 2])
                      pointArray.push([end_point[0] - 30, end_point[1]])
                      pointArray.push([end_point[0] - 20, end_point[1]])
                    }
                  }
                } else {
                  //结束点在上
                  if (end_point[0] > start_point[0] + sShape.width / 2 + 30) {
                    baseProperty.height += 30
                    baseProperty.x = baseProperty.origin_x
                    pointArray.push([start_point[0], start_point[1] + 30])
                    pointArray.push([end_point[0] - 30, start_point[1] + 30])
                    pointArray.push([end_point[0] - 30, end_point[1]])
                    pointArray.push([end_point[0] - 20, end_point[1]])
                  } else {
                    if (end_point[0] > start_point[0] - sShape.width / 2) {
                      baseProperty.height += 30
                      if (end_point[0] > start_point[0]) {
                        baseProperty.width = baseProperty.width + sShape.width / 2 + 30
                      } else {
                        baseProperty.width = sShape.width / 2 + 30
                      }
                      baseProperty.x = baseProperty.origin_x - sShape.width / 2 - 30
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([start_point[0] - sShape.width / 2 - 30, start_point[1] + 30])
                      pointArray.push([start_point[0] - sShape.width / 2 - 30, end_point[1]])
                      pointArray.push([end_point[0] - 20, end_point[1]])
                    } else {
                      baseProperty.height += 30
                      baseProperty.width += 30
                      baseProperty.x = baseProperty.origin_x - baseProperty.width
                      pointArray.push([start_point[0], start_point[1] + 30])
                      pointArray.push([end_point[0] - 30, start_point[1] + 30])
                      pointArray.push([end_point[0] - 30, end_point[1]])
                      pointArray.push([end_point[0] - 20, end_point[1]])

                    }

                  }
                }
                break;
            }
          }
          if (s_index == 3) {
            switch (e_Index) {
              case 0:
                point_d = 'bottom'
                if (end_point[0] < start_point[0]) {//结束点在左
                  if (end_point[1] < start_point[1]) { //上
                    if (end_point[0] + endShape.width / 2 > start_point[0]) {
                      baseProperty.height += 30
                      baseProperty.width = baseProperty.width + endShape.width / 2 + 30
                      baseProperty.x = baseProperty.origin_x - baseProperty.width
                      baseProperty.y = baseProperty.origin_y - baseProperty.height
                      pointArray.push([end_point[0] - endShape.width / 2 - 30, start_point[1]])
                      pointArray.push([end_point[0] - endShape.width / 2 - 30, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      baseProperty.height += 30
                      baseProperty.x = baseProperty.origin_x - baseProperty.width
                      baseProperty.y = baseProperty.origin_y - baseProperty.height
                      let w_s2 = start_point[0] - (end_point[0] + endShape.width / 2)
                      w_s2 = w_s2 > 60 ? 30 : w_s2 / 2
                      pointArray.push([start_point[0] - w_s2, start_point[1]])
                      pointArray.push([start_point[0] - w_s2, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    }

                  } else {//左下
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    baseProperty.y = baseProperty.origin_y
                    pointArray.push([end_point[0], start_point[1]])
                    pointArray.push([end_point[0], end_point[1] - 20])
                  }
                } else {///右边
                  if (end_point[1] < start_point[1]) {
                    if (end_point[0] - endShape.width / 2 < start_point[0]) {
                      baseProperty.width = endShape.width / 2 + 30
                      baseProperty.height += 30
                      baseProperty.x = baseProperty.origin_x - (start_point[0] - (end_point[0] - baseProperty.width / 2 - 30))
                      baseProperty.y = baseProperty.origin_y - baseProperty.height
                      pointArray.push([end_point[0] - baseProperty.width / 2 - 30, start_point[1]])
                      pointArray.push([end_point[0] - baseProperty.width / 2 - 30, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      baseProperty.height += 30
                      baseProperty.width += 30
                      baseProperty.x = baseProperty.origin_x - 30
                      baseProperty.y = baseProperty.origin_y - baseProperty.height
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    }
                  } else {
                    if (end_point[1] < start_point[1] + sShape.height / 2 + 30) {
                      baseProperty.height = baseProperty.height + endShape.height / 2 + 30
                      baseProperty.width += 30
                      baseProperty.x = baseProperty.origin_x - 30
                      baseProperty.y = baseProperty.origin_y - endShape.height / 2 - 30
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, start_point[1] - endShape.height / 2 - 30])
                      pointArray.push([end_point[0], start_point[1] - endShape.height / 2 - 30])
                      pointArray.push([end_point[0], end_point[1] - 20])
                    } else {
                      baseProperty.width += 30
                      baseProperty.x = baseProperty.origin_x - 30
                      baseProperty.y = baseProperty.origin_y
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, end_point[1] - 30])
                      pointArray.push([end_point[0] - 30, end_point[1] - 30])
                      pointArray.push([end_point[0] - 30, end_point[1] - 20])
                    }

                  }

                }
                break;
              case 1:
                point_d = 'left'
                if (end_point[0] < start_point[0]) {//结束在左
                  if (start_point[0] - end_point[0] > 30) {
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    let w_s5 = baseProperty.width
                    if (w_s5 < 60) {
                      w_s5 = w_s5 - 30
                    } else {
                      w_s5 = baseProperty.width / 2
                    }
                    pointArray.push([start_point[0] - w_s5, start_point[1]])
                    pointArray.push([start_point[0] - w_s5, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else {
                    if (end_point[1] < start_point[1]) {
                      baseProperty.width = 60 - baseProperty.width
                      baseProperty.x = baseProperty.origin_x - 30
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, start_point[1] - baseProperty.height / 2])
                      pointArray.push([end_point[0] + 30, start_point[1] - baseProperty.height / 2])
                      pointArray.push([end_point[0] + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    } else {
                      baseProperty.width = 60 - baseProperty.width
                      baseProperty.x = baseProperty.origin_x - 30
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, start_point[1] + baseProperty.height / 2])
                      pointArray.push([end_point[0] + 30, start_point[1] + baseProperty.height / 2])
                      pointArray.push([end_point[0] + 30, end_point[1]])
                      pointArray.push([end_point[0] + 20, end_point[1]])
                    }

                  }

                } else {
                  if (end_point[1] + endShape.height / 2 < start_point[1] - sShape.height / 2) {
                    baseProperty.width += 60
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] - baseProperty.height / 2])
                    pointArray.push([end_point[0] + 30, start_point[1] - baseProperty.height / 2])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else if (end_point[1] < start_point[1]) {
                    baseProperty.height = baseProperty.height + 30 + sShape.height / 2
                    baseProperty.width += 60
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y - (baseProperty.height - 30 - sShape.height / 2)
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] + sShape.height / 2 + 30])
                    pointArray.push([end_point[0] + 30, start_point[1] + sShape.height / 2 + 30])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else if (end_point[1] - endShape.height / 2 < start_point[1] + sShape.height / 2) {
                    baseProperty.width += 60
                    baseProperty.height = baseProperty.height + sShape.height / 2 + 30
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y - sShape.height / 2 - 30
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] - sShape.height / 2 - 30])
                    pointArray.push([end_point[0] + 30, start_point[1] - sShape.height / 2 - 30])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  } else {
                    baseProperty.width += 60
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] + baseProperty.height / 2 - sShape.height / 4 + endShape.height / 4])
                    pointArray.push([end_point[0] + 30, start_point[1] + baseProperty.height / 2 - sShape.height / 4 + endShape.height / 4])
                    pointArray.push([end_point[0] + 30, end_point[1]])
                    pointArray.push([end_point[0] + 20, end_point[1]])
                  }

                }
                break;
              case 2:
                point_d = 'top'
                if (end_point[0] > start_point[0]) {
                  if (end_point[1] < start_point[1] - sShape.height / 2 - 30) {
                    baseProperty.width += 30
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])

                  } else if (end_point[1] < start_point[1]) {
                    baseProperty.width += 30
                    baseProperty.height = baseProperty.height + sShape.height / 2 + 30
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y - (baseProperty.height - sShape.height / 2 - 30)
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] + sShape.height / 2 + 30])
                    pointArray.push([end_point[0], start_point[1] + sShape.height / 2 + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  } else if (end_point[1] < start_point[1] + sShape.height / 2) {
                    baseProperty.width += 30
                    baseProperty.height = sShape.height / 2 + 30
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, start_point[1] + baseProperty.height])
                    pointArray.push([end_point[0], start_point[1] + baseProperty.height])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  } else {
                    baseProperty.width += 30
                    baseProperty.height = baseProperty.height + endShape.height / 2 + 30
                    baseProperty.x = baseProperty.origin_x - 30
                    baseProperty.y = baseProperty.origin_y
                    pointArray.push([start_point[0] - 30, start_point[1]])
                    pointArray.push([start_point[0] - 30, end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 30])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  }
                } else {
                  if (end_point[1] < start_point[1] - 30) {
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    pointArray.push([end_point[0], start_point[1]])
                    pointArray.push([end_point[0], end_point[1] + 20])
                  } else {
                    if (end_point[1] < start_point[1]) {
                      baseProperty.height = 30
                      baseProperty.x = baseProperty.origin_x - baseProperty.width
                      baseProperty.y = baseProperty.origin_y - (start_point[1] - end_point[1])
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    } else {
                      baseProperty.height += 30
                      baseProperty.y = baseProperty.origin_y
                      baseProperty.x = baseProperty.origin_x - baseProperty.width
                      pointArray.push([start_point[0] - 30, start_point[1]])
                      pointArray.push([start_point[0] - 30, end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 30])
                      pointArray.push([end_point[0], end_point[1] + 20])
                    }

                  }
                }
                break;
              case 3:
                point_d = 'right'
                if (end_point[0] > start_point[0]) {//结束右
                  baseProperty.width += 30
                  if (end_point[1] < start_point[1]) {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    baseProperty.x = baseProperty.origin_x - 30
                  } else {
                    baseProperty.y = baseProperty.origin_y
                    baseProperty.x = baseProperty.origin_x - 30
                  }
                  pointArray.push([start_point[0] - 30, start_point[1]])
                  pointArray.push([start_point[0] - 30, end_point[1]])
                  pointArray.push([end_point[0] - 20, end_point[1]])

                } else {
                  baseProperty.width += 30
                  if (end_point[1] < start_point[1]) {
                    baseProperty.y = baseProperty.origin_y - baseProperty.height
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                  } else {
                    baseProperty.y = baseProperty.origin_y
                    baseProperty.x = baseProperty.origin_x - baseProperty.width
                  }
                  pointArray.push([end_point[0] - 30, start_point[1]])
                  pointArray.push([end_point[0] - 30, end_point[1]])
                  pointArray.push([end_point[0] - 20, end_point[1]])
                }
                break;
            }

          }
          pointArray.push(end_point)
          this.drawLine(baseProperty.id, pointArray, point_d, baseProperty.height, baseProperty.width)

        } else {  ///结束点非关联
          ctx.save()
          ctx.clearRect(0, 0, baseProperty.width + 20, baseProperty.height + 20)
          ctx.beginPath()
          //起始点在左上角不用转换坐标系
          let x = 0
          let y = 0
          if (baseProperty.pos[0][0] > baseProperty.pos[baseProperty.pos.length - 1][0]) {
            x = baseProperty.pos[0][0] - baseProperty.pos[baseProperty.pos.length - 1][0]
          }
          if (baseProperty.pos[0][1] > baseProperty.pos[baseProperty.pos.length - 1][1]) {
            y = baseProperty.pos[0][1] - baseProperty.pos[baseProperty.pos.length - 1][1]
          }
          ctx.translate(x, y)
          ctx.moveTo(10, 10)

          if (s_index == 1 || s_index == 3) {
            pointType = 1   //左右方向
          } else {
            pointType = 2  //上下方向
          }

          if (pointType == 1) {
            if (Math.abs(start_point[1] - end_point[1]) <= 8) {
              ///不用拆分线段
              direction = 'right'
              if (start_point[0] > end_point[0]) {
                direction = 'left'
              }
            } else {
              if (baseProperty.width >= baseProperty.height) { //箭头向右或者左
                if (start_point[0] > end_point[0]) {
                  direction = 'left'
                  centerList.push([start_point[0] - baseProperty.width / 2, start_point[1]])
                  centerList.push([start_point[0] - baseProperty.width / 2, end_point[1]])
                } else {
                  direction = 'right'
                  centerList.push([start_point[0] + baseProperty.width / 2, start_point[1]])
                  centerList.push([start_point[0] + baseProperty.width / 2, end_point[1]])
                }
              } else {
                centerList.push([end_point[0], start_point[1]])
                if (end_point[1] < start_point[1]) { //箭头向上
                  direction = 'top'
                } else {  //箭头向下
                  direction = 'bottom'
                }
              }
            }
          } else if (pointType == 2) {
            if (Math.abs(start_point[0] - end_point[0]) <= 8) {
              ///不用拆分线段
              direction = 'top'
              if (end_point[1] > start_point[1]) {
                direction = 'bottom'
              }
            } else {
              if (baseProperty.height >= baseProperty.width) {
                if (start_point[1] > end_point[1]) {
                  direction = 'top'
                  centerList.push([start_point[0], end_point[1] + baseProperty.height / 2])
                  centerList.push([end_point[0], end_point[1] + baseProperty.height / 2])
                } else {
                  direction = 'bottom'
                  centerList.push([start_point[0], end_point[1] - baseProperty.height / 2])
                  centerList.push([end_point[0], end_point[1] - baseProperty.height / 2])
                }
              } else {
                centerList.push([start_point[0], end_point[1]])
                if (end_point[0] < start_point[0]) {
                  direction = 'left'
                } else {
                  direction = 'right'
                }
              }
            }
          }
        }
        if (baseProperty.e_id) {
          return
        }
        ///结束非关联点
        if (pointType == 1) {
          if (centerList.length == 0) {
            centerList.push([end_point[0], start_point[1]])
          } else {
            centerList.push(end_point)
          }
        } else if (pointType == 2) {
          if (centerList.length == 0) {
            centerList.push([start_point[0], end_point[1]])
          } else {
            centerList.push(end_point)
          }
        }

        centerList.forEach((item, index) => {
          if (index == centerList.length - 1) {
            if (direction == 'right') {
              ctx.lineTo(item[0] - baseX - 10, item[1] - baseY + 10)
              ctx.moveTo(item[0] - baseX - 10, item[1] - baseY + 10)
            }
            if (direction == 'left') {
              ctx.lineTo(item[0] - baseX + 10 + 20, item[1] - baseY + 10)
              ctx.moveTo(item[0] - baseX + 10 + 20, item[1] - baseY + 10)
            }
            if (direction == 'top') {
              ctx.lineTo(item[0] - baseX + 10, item[1] - baseY + 10 + 20)
              ctx.moveTo(item[0] - baseX + 10, item[1] - baseY - 10 + 20)
            }
            if (direction == 'bottom') {
              ctx.lineTo(item[0] - baseX + 10, item[1] - baseY - 10)
              ctx.moveTo(item[0] - baseX + 10, item[1] - baseY - 10)
            }
          } else {
            ctx.lineTo(item[0] - baseX + 10, item[1] - baseY + 10)
          }
        })

        // baseProperty.pos.forEach((item, index) => {
        //   if (index == baseProperty.pos.length - 1) {
        //     ctx.lineTo(item[0] - baseX + 10, item[1] - baseY + 10)
        //   }
        // })
        ctx.lineWidth = 2
        ctx.closePath()
        ctx.strokeStyle = '#000'
        ctx.stroke()
        if (direction == 'right') {
          ctx.beginPath()
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX - 10, centerList[centerList.length - 1][1] - baseY + 10 - 5)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10, centerList[centerList.length - 1][1] - baseY + 10)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX - 10, centerList[centerList.length - 1][1] - baseY + 10 + 5)

        }
        if (direction == 'left') {
          ctx.beginPath()
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 + 20, centerList[centerList.length - 1][1] - baseY + 10 - 5)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10, centerList[centerList.length - 1][1] - baseY + 10)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 + 20, centerList[centerList.length - 1][1] - baseY + 10 + 5)
        }
        if (direction == 'top') {
          ctx.beginPath()
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 - 5, centerList[centerList.length - 1][1] - baseY + 10 + 20)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10, centerList[centerList.length - 1][1] - baseY + 10)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 + 5, centerList[centerList.length - 1][1] - baseY + 10 + 20)
        }
        if (direction == 'bottom') {
          ctx.beginPath()
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 - 5, centerList[centerList.length - 1][1] - baseY - 10)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10, centerList[centerList.length - 1][1] - baseY - 10 + 20)
          ctx.lineTo(centerList[centerList.length - 1][0] - baseX + 10 + 5, centerList[centerList.length - 1][1] - baseY - 10)
        }
        if (direction) {
          ctx.closePath()
          ctx.fillStyle = '#000'
          ctx.fill()
        }
        ctx.restore()
      },

      drawLine(id, data, point_d, height, width) {
        if (id && data.length > 1) {
          new Promise((resolve, reject) => {
            this.getDomById(resolve, id, 1)
          }).then((ctx) => {
            ctx.save()
            ctx.translate(0, 0)
            ctx.clearRect(0, 0, width + 20, height + 20)
            ctx.beginPath()
            //计算起始点坐标
            let baseX = 0
            let baseY = 0
            data.forEach((item, index) => {
              if (index == 0) {
                baseX = item[0]
                baseY = item[1]
              } else {
                if (baseX > item[0]) {
                  baseX = item[0]
                }
                if (baseY > item[1]) {
                  baseY = item[1]
                }
              }
            })
            data.forEach((item, index) => {
              if (index == 0) {
                ctx.moveTo(item[0] - baseX + 10, item[1] - baseY + 10)
              }
              if (index > 0 && index < data.length - 1) {
                ctx.lineTo(item[0] - baseX + 10, item[1] - baseY + 10)
                ctx.moveTo(item[0] - baseX + 10, item[1] - baseY + 10)
              }
            })
            ctx.lineWidth = 2
            ctx.closePath()
            ctx.strokeStyle = '#000'
            ctx.stroke()
            let endData = data[data.length - 2]
            if (point_d == 'right') {
              ctx.beginPath()
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 + 5)
              ctx.lineTo(endData[0] - baseX + 10 + 20, endData[1] - baseY + 10)
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 - 5)
            }
            if (point_d == 'left') {
              ctx.beginPath()
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 - 5)
              ctx.lineTo(endData[0] - baseX + 10 - 20, endData[1] - baseY + 10)
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 + 5)
            }
            if (point_d == 'top') {
              ctx.beginPath()
              ctx.lineTo(endData[0] - baseX + 10 - 5, endData[1] - baseY + 10)
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 - 20)
              ctx.lineTo(endData[0] - baseX + 10 + 5, endData[1] - baseY + 10)
            }
            if (point_d == 'bottom') {
              ctx.beginPath()
              ctx.lineTo(endData[0] - baseX + 10 - 5, endData[1] - baseY + 10)
              ctx.lineTo(endData[0] - baseX + 10, endData[1] - baseY + 10 + 20)
              ctx.lineTo(endData[0] - baseX + 10 + 5, endData[1] - baseY + 10)
            }
            if (point_d) {
              ctx.closePath()
              ctx.fillStyle = '#000'
              ctx.fill()
            }
            ctx.restore()
          })
        }
      },
      /*
      * 绘制等腰三角形 高度垂直
      * params:{canvas2d上下文对象，基本属性，基本样式}
      * */
      drawAngle(ctx, baseProperty, baseStyle) {

        function action(ctx, x, y, width, height, color = '#000000', type = 'stroke') {
          ctx.beginPath()
          ctx.moveTo(x, y)
          ctx.lineTo(x + width, y + Math.ceil(height / 2))
          ctx.lineTo(x, y + Math.ceil(height))
          ctx[type + 'Style'] = color
          ctx.closePath()
          ctx[type]()
        }

        action(ctx, 10, 10, baseProperty.width, baseProperty.height, baseStyle.color, baseStyle.type)
      },

      getValue() {
        if (this.showRightValue && this.isCheck) {
          let result = this.getRightValue().result
          let result_data = this.getRightValue().data
          this.isCheck.value = result
          this.isCheck.data = JSON.parse(JSON.stringify(result_data))
          this.shapeArray.forEach((item) => {
            if (item.id == this.isCheck.id) {
              item.value = JSON.parse(JSON.stringify(this.isCheck.value))
            }
          })
        }
        let result = []
        this.shapeArray.forEach((item, index) => {
          let obj = null
          if (item.type == 'round') {
            obj = {
              x: item.x,
              y: item.y,
              radius: item.radius,
              value: item.value || null,
              prev: '',
              next: '',
              id: item.id,
              type: 'round',
              data: item.data || null
            }
          }
          if (item.type == 'rectangle') {
            obj = {
              x: item.x,
              y: item.y,
              width: item.width,
              height: item.height,
              value: item.value || null,
              prev: '',
              next: '',
              id: item.id,
              type: 'rectangle',
              data: item.data || null
            }
          }
          if (item.label) {
            obj.label = item.label
          }
          for (let i = 0; i < this.lineArray.length; i++) {
            let s_id = this.lineArray[i].s_id
            let e_id = this.lineArray[i].e_id
            if (s_id) {
              if (s_id.split('_')[0] == item.id) {
                if (e_id) {
                  if (obj.next) {
                    obj.next = ',' + this.lineArray[i].e_id.split('_')[0]
                  } else {
                    obj.next = this.lineArray[i].e_id.split('_')[0]
                  }

                }
              }
            }
            if (e_id) {
              if (e_id.split('_')[0] == item.id) {
                if (s_id) {
                  if (obj.prev) {
                    obj.prev = ',' + this.lineArray[i].s_id.split('_')[0]
                  } else {
                    obj.prev = this.lineArray[i].s_id.split('_')[0]
                  }
                }
              }
            }
          }
          result.push(obj)
        })
        this.lineArray.forEach((itmes, index) => {
          let obj = {
            type: itmes.type,
            pos: itmes.pos,
            prev: itmes.s_id,
            next: itmes.e_id,
          }
          obj.pos.push([itmes.x, itmes.y])
          obj.pos.push([itmes.origin_x, itmes.origin_y])
          result.push(obj)
        })
        if (this.isCheck && this.showCheck) {
          result.forEach((item, index) => {
            if (this.isCheck.id == item.id) {
              item.select = true
            }
          })
        }
        return JSON.stringify(result)
      },

      /*
      * 图形点击，开始编辑文字
      * */
      shapeEdit(item) {
        // console.log(item)
        this.editItem = JSON.parse(JSON.stringify(item))
        this.editPlace = {
          left: item.x + 15 + 'px',
          top: item.y + 15 + 'px',
          width: item.width - 10 + 'px',
          height: item.height - 10 + 'px',
        }
        if (item.type == "round") {
          this.editPlace = {
            left: item.x + 20 + 'px',
            top: item.y + 20 + 'px',
            width: item.width - 20 + 'px',
            height: item.height - 20 + 'px',
          }
        }
        if (this.editItem.label) {
          this.textValue = this.editItem.label
        }
        this.isEdit = true
        setTimeout(() => {
          this.$refs.editText.focus({preventScroll: true})
        }, 200)
      },
      /*
      * 编辑时输入值改变
      * */
      editChange() {
        if (this.editItem && this.isEdit) {
          this.shapeArray.forEach((item, index) => {
            if (item.id == this.editItem.id) {
              item.label = this.textValue
              new Promise((resolve, reject) => {
                this.getDomById(resolve, item.id, 1)
              }).then((res) => {
                this.draw(res, item)
              })
            }
          })
        }
        this.textValue = ''
        this.isEdit = false
      },
    },
  }
</script>

<style lang="scss" scoped>
  .flowBox {
    position: relative;

    div {
      user-select: none;
    }

    .link_point_canvas {
      background-color: rgba(0, 0, 0, .1);
      border-radius: 50%;
    }

    .left_Box {
      width: 70px;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      background-color: #fff;
      overflow-y: auto;
      box-shadow: 0px 0px 3px #D8D9DD;
      white-space: normal;

      .iconBtn {
        width: 100%;
        text-align: center;
        cursor: pointer;
        line-height: 50px;

        &:hover {
          background-color: #ccc;
        }
      }
    }

    .right_box {
      height: 100%;
      position: absolute;
      top: 0;
      right: 0;
      background-color: #fff;
      /*overflow-y: auto;*/
      box-shadow: 0px 0px 3px #D8D9DD;

      .left_move {
        width: 4px;
        height: 100%;
        cursor: auto;

        &:hover {
          cursor: w-resize;
        }
      }
    }

    .center_box {
      /*width: calc(100% - 420px);*/
      /*height: 100%;*/
      overflow: auto;
      position: absolute;
      left: 100px;
      top: 0;
      background-color: #fff;

      /*图形样式*/
      .shape_box {
        position: absolute;
        overflow: visible;
      }

      /*线样式*/
      .lineBox {
        position: absolute;
      }

      /*画线点样式*/
      .shape_contour {
        position: absolute;
        width: 0;
        height: 0;
        overflow: visible;

        .ponit_item {
          position: absolute;
          border: 1px solid #883333;
          width: 8px;
          height: 8px;
          border-radius: 5px;
          background-color: #fff;
          cursor: crosshair;
          box-sizing: content-box;
        }
      }

      /*缩放控制器样式*/
      .shape_controls {
        position: absolute;
        border: 1px solid #883333;
        box-sizing: content-box;
        overflow: visible;

        .shape_controller {
          width: 6px;
          height: 6px;
          border: 1px solid #883333;
          background-color: #fff;
          position: absolute;
          box-sizing: content-box;
        }

        .nw {
          cursor: nw-resize;
        }

        .ne {
          cursor: ne-resize;
        }

        .se {
          cursor: se-resize;
        }

        .sw {
          cursor: sw-resize;
        }
      }


    }

    .editText {
      position: absolute;
      z-index: 999;
      border: 1px solid #f0c78a;
      overflow: hidden;

      .input_text {
        border: none;
        outline: none;
        width: 100%;
        resize: none;
      }

      .input_text:focus {
        outline: none;
      }
    }
  }
</style>
